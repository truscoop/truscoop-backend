# newsapp-backend

Net IDs: dc863 ssd76
The database description is in src/spec.md
